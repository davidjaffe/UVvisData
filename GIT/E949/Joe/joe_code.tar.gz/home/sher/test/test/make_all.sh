#!/bin/tcsh

touch e*.f

make -f Makefile9597inside
make -f Makefile9597insidelo
make -f Makefile9597insidehi
make -f Makefile98inside
make -f Makefile98insidelo
make -f Makefile98insidehi
make -f Makefile98outside
make -f Makefile98outside0
make -f Makefile98total
make -f Makefile9598inside
make -f Makefile9598insidelo
make -f Makefile9598insidehi
make -f Makefile9598outside
make -f Makefile9598outside0
make -f Makefile9598total

exit 0

